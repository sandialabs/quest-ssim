Unreleased
----------

    See on GitHub: `branch master <https://github.com/kivymd/KivyMD/tree/master>`_ | `compare 1.0.1/master <https://github.com/kivymd/KivyMD/compare/1.0.1...master>`_

    .. code-block:: bash

       pip install https://github.com/kivymd/KivyMD/archive/master.zip

* Bug fixes and other minor improvements.
* Added a button to copy the code to the documentation.
* Added the feature to view code examples of documentation in imperative and declarative styles.
